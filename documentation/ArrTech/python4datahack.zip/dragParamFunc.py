import math

def airDens(z):
    func = [ -4.21850192e-14, 3.74078897e-09, -1.14758990e-04, 1.22238513]
    AirDens = func[0]*z*z*z + func[1]*z*z +func[2]*z + func[3]
    #airDensFunc = [ -4.21850192e-14, 3.74078897e-09, -1.14758990e-04, 1.22238513]
    return AirDens

# z = (-g-(v[t+1]-v[t-1]) / ( v[t] abs(v[t]) r[z[t]])
# vz[] - array of velZ for single line
# z[] - array of posZ for the same single line
def DragParamFuncBallisticZ(vz=[],z=[]):
    g = 9.8
    num = 1
    dragParam = 0
    for i in range(1,29):
        if (math.isnan(vz[i+1])):
            num = i
            break
        r = airDens(z[i])
        dragParam = dragParam + (-g - vz[i+1] + vz[i-1]) / (vz[i]*abs(vz[i])*r)
    dragParam = dragParam/num
    return dragParam

# x = (-(v[t+1]-v[t-1]) / ( v[t] abs(v[t]) r[z[t]])
# vx[] - array of velX for single line
# z[] - array of posZ for the same single line
def DragParamFuncBallisticX(vx=[],z=[]):
    g = 9.8
    num = 1
    dragParam = 0
    for i in range(1,29):
        if (math.isnan(vx[i+1])):
            num = i
            break
        r = airDens(z[i])
        dragParam = dragParam + (- vx[i+1] + vx[i-1]) / (vx[i]*abs(vx[i])*r)
    dragParam = dragParam/num
    return dragParam

