def airDens(z):
    func = [ -4.21850192e-14, 3.74078897e-09, -1.14758990e-04, 1.22238513]
    AirDens = func[0]*z*z*z + func[1]*z*z +func[2]*z + func[3]
    #airDensFunc = [ -4.21850192e-14, 3.74078897e-09, -1.14758990e-04, 1.22238513]
    return AirDens