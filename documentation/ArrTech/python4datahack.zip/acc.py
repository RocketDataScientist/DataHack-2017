import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import math

original = pd.read_csv('C:/Users/user/desktop/dataHack/test.csv')
#original = pd.read_csv('C:/Users/user/desktop/dataHack/test.csv')
transposed = original.transpose()
#print(transposed)
clean  = transposed.iloc[1:] # get rid of redundant line
velZ = clean.loc[clean.index.str.startswith('velZ')]
velX = clean.loc[clean.index.str.startswith('velX')]
velZ = velZ.transpose()
velX = velX.transpose()
#print velZ[:1]


velZ = np.asarray(velZ, dtype=np.float32)
velX = np.asarray(velX, dtype=np.float32)
#velZ = np.array(velZ)
#time = np.linspace(0,14.5,num=30)
#print time
index = range(len(velZ)-1)
accZ = range(len(velZ)-1)
accX = range(len(velZ)-1)
#print velZ

for i in index:

    #print velZ[i]
    #velZ[i] = velZ
    temp_velZ = np.array(velZ[i])
    temp_velX = np.array(velX[i])
    #print temp_velZ

    temp_velZ =  temp_velZ[~np.isnan(temp_velZ)]
    temp_velX =  temp_velX[~np.isnan(temp_velX)]
    #print temp_velZ
    #print temp_velX
    accZ[i] = np.polyfit(range(len(temp_velZ)),temp_velZ,1)
    accX[i] = np.polyfit(range(len(temp_velX)),temp_velX,1)
    #print i,accZ[i],accX[i]
#print time[3],velZ[3]

###########################
accZ = np.array(accZ)
accZ_frame0 = pd.DataFrame(accZ[:,0])
accZ_frame1 = pd.DataFrame(accZ[:,1])
accZ_frame0.to_csv("test_accZ_frame0")
accZ_frame1.to_csv("test_accZ_frame1")
#dragZ_frame.to_pickle('pickle_dragZ') #will create a file with name "pickled_array" - send me this file, repeat for 2nd array

accX = np.array(accX)
accX_frame0 = pd.DataFrame(accX[:,0])
accX_frame1 = pd.DataFrame(accX[:,1])
accX_frame0.to_csv("test_accX_frame0")
accX_frame1.to_csv("test_accX_frame1")
#dragX_frame.to_pickle('pickle_dragX') #will create a file with name "pickled_array" - send me this file, repeat for 2nd array
##############################

# x= 811
# temp_velZ = np.array(velZ[x])
# temp_velZ =  temp_velZ[~np.isnan(temp_velZ)]
# time = range(len(temp_velZ))
#
# plt.figure(1)
# #plt.title('acc[1] in z')
# plt.plot(time,temp_velZ)
# plt.plot(np.polyval(accZ[x],time))
# #plt.plot(index,dragZ)
# print accZ[x]
#
# temp_velX = np.array(velX[x])
# temp_velX =  temp_velX[~np.isnan(temp_velX)]
# plt.figure(2)
# #plt.title('acc[1] in z')
# plt.plot(time,temp_velX)
# plt.plot(np.polyval(accX[x],time))
# #plt.plot(index,dragZ)
# print accX[x]
#
# plt.show()

