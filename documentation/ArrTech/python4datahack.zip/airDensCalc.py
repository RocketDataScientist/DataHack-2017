import atmos
import numpy as np
import pandas as pd
import math

original = pd.read_csv('C:/Users/user/desktop/dataHack/AirDens.csv')
original = original.iloc[:32]
transposed = original.transpose()
clean  = transposed.iloc[:2] # get rid of redundant line

height = np.array(clean[:1])
airDens = np.array(clean[1:])

height = height[0,:] # fix to 1D
airDens = airDens[0,:] # fix to 1D

func = np.polyfit(height,airDens,3)
#print (func)

z=11784
# height in meters
#final air density in pascal
AirDens = func[0]*z*z*z + func[1]*z*z +func[2]*z + func[3]
#print func
#print AirDens
airDensFunc = [ -4.21850192e-14, 3.74078897e-09, -1.14758990e-04, 1.22238513]
print airDensFunc

#calculate air density
# z - heghit above see level [meter]
# Tv - temprature in K
# p - air preasure pascal
#AirDens = atmos.calculate('rho',z=628,Tv=280,p=950*100)

#print(AirDens)

