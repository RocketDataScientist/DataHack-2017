import pandas as pd
from dragParamFunc import DragParamFuncBallisticZ
from dragParamFunc import DragParamFuncBallisticX

clean = pd.read_csv('C:/Users/user/desktop/dataHack/test.csv', chunksize=1000)
clean = clean.transpose()
#print(transposed)
clean  = clean.iloc[1:] # get rid of redundant line
#time = clean.loc[clean.index.str.startswith('Time')]
#df.loc[df['column_name'].isin(some_values)]

posZ = clean.loc[clean.index.str.startswith('posZ')]
#posX = clean.loc[clean.index.str.startswith('posX')]
velX = clean.loc[clean.index.str.startswith('velX')]
velZ = clean.loc[clean.index.str.startswith('velZ')]
cla  = clean.loc[clean.index.str.startswith('cla')]
#print posZ[23],velZ[23]

#color = cm.rainbow(np.linspace(0,24,num=25))
#color = ['red','green','blue','black','pink','yellow']
max = 271251 #28745

index = range (max)
dragX = range (max)
dragZ = range (max)

for i in index:
    dragZ[i] = DragParamFuncBallisticZ(velZ[i],posZ[i])
    #if abs(z[i])>1000: z[i] = 0
    #dragX[i] = DragParamFuncBallisticX(velX[i],posZ[i])
    #if abs(dragX[i])>0.1: print i,dragX[i],dragZ[i]
    #if dragZ[i]<0: print i,dragX[i],dragZ[i]

###########################
dragZ_frame = pd.DataFrame(dragZ)
dragZ_frame.to_csv("dragZ_frame")
#dragZ_frame.to_pickle('pickle_dragZ') #will create a file with name "pickled_array" - send me this file, repeat for 2nd array
#dragX_frame = pd.DataFrame(dragX)
#dragX_frame.to_csv("dragX_frame")
#dragX_frame.to_pickle('pickle_dragX') #will create a file with name "pickled_array" - send me this file, repeat for 2nd array
##############################