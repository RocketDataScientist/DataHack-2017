import numpy as np
import pandas as pd
import math

# D = 0.5 * Cd * r * A * v^2
# D - drag force
# Cd - drag coefficient
# r - air density
# A - Area of rocket
# v - velocity
